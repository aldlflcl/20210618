
public class ����6 {

	public static void main(String[] args) {
		
		for(int i = 10; i <= 99; i++) {
			
			if(i % 11 == 0) {
				System.out.printf("%d ", i);
			}
		}
	}
}
